package com.example.myapplication.data.dto

class LoginRequest(
    val username: String,
    val password: String
)