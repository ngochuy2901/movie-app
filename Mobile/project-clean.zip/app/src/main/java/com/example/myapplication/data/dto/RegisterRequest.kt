package com.example.myapplication.data.dto

class RegisterRequest {
}