package com.example.myapplication.ui.screen

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController

@Composable
fun NotificationScreen(navHostController: NavHostController) {

}

@Composable
@Preview
fun NotificationScreenPreview() {
    NotificationScreen(rememberNavController())
}